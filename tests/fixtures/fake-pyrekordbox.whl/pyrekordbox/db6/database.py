import logging

BLOB = b"NUeDVe13g;bsy?3DJdvrFxv|x82"

logger = logging.getLogger(__name__)

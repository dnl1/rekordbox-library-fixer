import zlib

# A made-up key, for tests.
BLOB_KEY = b"0123456789abcdef"

def deobfuscate(blob): ...
